function im=CreateGaussNoise(N,sig)

%Creates an image of size N, which can be an integer (square NxN image) or 
%a 2-element vector (N(1)xN(2) image), of Gaussian noise with kernel sig. 
%The default value for sig is related to the size of the image.

if nargin<2
    sig=8e-4*min(N);
end

im=normalizeIm(imgaussfilt(randn(N),sig,'Padding','symmetric'));