function Inrm=normalizeIm(Im,Imax,Imin)

%Normalize input image Im with a linear mapping that converts intensity
%values between Imin and Imax to the interval [0,1]. Default values for 
%Imax and Imin are the maximum and minimum values in the image

if nargin<2
    Imax=max(Im(:));
    Imin=min(Im(:));
end

Inrm=(Im-Imin)/(Imax-Imin);
Inrm(Inrm>1)=1;
Inrm(Inrm<0)=0;