Add this folder to your main path to create colored LIC images. 

The main script is CreateLIC.m, the other scripts are called by CreateLIC.

Please see the script testLIC.m for an example of usage.