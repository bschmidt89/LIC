clear variables
close all
clc

%Test LIC visualization

load('LICdata.mat','V')

N=size(V,1);

Llic=50;

%Gaussian Noise
opts.Vnorm=1;
opts.BOS=0;

opts.imtype='Gaussian';
LIC=CreateLIC(V,Llic,opts);

q=1;

figure(q)
imshow(LIC,'InitialMagnification','fit')
colormap parula
q=q+1;

%Perlin
opts.imtype='Perlin';
LIC=CreateLIC(V,Llic,opts);

figure(q)
imshow(LIC,'InitialMagnification','fit')
colormap parula
q=q+1;

%Wavelet
opts.imtype='Wavelet';
LIC=CreateLIC(V,Llic,opts);

figure(q)
imshow(LIC,'InitialMagnification','fit')
colormap parula
q=q+1;