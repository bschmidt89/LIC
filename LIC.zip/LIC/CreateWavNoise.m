function im=CreateWavNoise(N,options)

%Create a textured square image of wavelet noise of size N, which must be a
%power of 2. options is an optional structure containing the following
%fields:
%
%Jmax: maximum scale for wavelet noise. Smaller values lead to coarser
%images. Default is log2(N).
%
%Jmin: minimum scale for wavelet noise. Smaller values lead to coarser
%images. Default is Jmax-2.
%
%wname: Wavelet function used to generate the noise. Default is 'bior4.4'.

if nargin<2
    options=[];
end

if ~isfield(options,'Jmax')
    Jmax=log2(N);
else
    Jmax=options.Jmax;
end

if ~isfield(options,'Jmin')
    Jmin=Jmax-2;
else
    Jmin=options.Jmin;
end

if ~isfield(options,'wname')
    wname='bior4.4';
else
    wname=options.wname;
end

im=zeros(N);
for j=Jmax:-1:Jmin
    R=rand(2^j);
    [c,~]=wavedec2(R,1,wname);
    c(1:end/4)=0;
    c=[c,zeros(1,N^2-length(c))];
    s=repmat([2^(j-1);(2.^((j-1):log2(N)))'],1,2);

    im=im+waverec2(c,s,wname)/2^j;
end
im=normalizeIm(im);