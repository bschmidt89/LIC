function LICim=CreateLIC(V,Llic,opts)

%Creates a line integral convolution image from a vector field V and an
%input image im. Llic is the length of the convolution in pixels, typically
%50 is a good starting point. opts is an optional structure with the 
%following possible fields:
%
%Vnorm: Normalize all vectors to unit length if the value is 1. Only 
%recommended for very clean data, doesn't work well with BOS. Default is 0 
%(non-normalized).
%
%BOS: Flips the x- and y- directions of the vector field if the value is 1,
%useful for BOS such that lines are isocontours of the optical index
%gradient field. Default is 0.
%
%Normalize: Normalizes the image at the end. Works well for single data
%sets, but if you want to compare different cases directly, you should turn
%this off. Default is 1 (normalized).
%
%imtype: Choice of the starting image texture. Can either be 'Gaussian', 
%'Perlin', or 'Wavelet'. Default is Perlin.
%
%imopts: Optional parameters for the starting image texture. Consult the
%scripts CreateGaussNoise.m, CreatePerlNoise.m, and CreateWavNoise.m for
%guidance and options for setting these parameters. Generally, the defaults
%work well.

Vmag=hypot(V(:,:,1),V(:,:,2));

if nargin<3
    opts=[];
end

if ~isfield(opts,'imtype')
    opts.imtype='Perlin';
end

switch opts.imtype
    case 'Perlin'
        if ~isfield(opts,'imopts')
            im=CreatePerlNoise([size(V,1),size(V,2)]);
        else
            im=CreatePerlNoise([size(V,1),size(V,2)],opts.imopts);
        end
    case 'Gaussian'
        if ~isfield(opts,'imopts')
            im=CreateGaussNoise([size(V,1),size(V,2)]);
        else
            im=CreateGaussNoise([size(V,1),size(V,2)],opts.imopts);
        end
    case 'Wavelet'
        if size(V,1)==size(V,2) && rem(log2(size(V,1)),1)==0
            if ~isfield(opts,'imopts')
                im=CreateWavNoise(size(V,1));
            else
                im=CreateWavNoise(size(V,1),opts.imopts);
            end
        else
            error(['Wavelet noise does not work if the image size is',...
                ' not both (i) square and (ii) a power of 2 in size!'])
        end
end

if ~isfield(opts,'Vnorm')
    opts.Vnorm=0;
end

if opts.Vnorm
    V=V./repmat(Vmag,[1,1,2]);
end

if ~isfield(opts,'BOS')
    opts.BOS=0;
end

if ~isfield(opts,'Normalize')
    opts.Normalize=1;
end

if opts.BOS
    V=cat(3,V(:,:,2),-V(:,:,1));
end

options.M0=im;

if opts.Normalize
    LICim=normalizeIm(Vmag.*normalizeIm(perform_lic(V,Llic,options)));
else
    LICim=Vmag.*normalizeIm(perform_lic(V,Llic,options));
end