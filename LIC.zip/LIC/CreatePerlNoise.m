function im=CreatePerlNoise(N,minperl)

%Creates a square image of size N of Perlin noise. N can be an integer 
%(square NxN image) or a 2-element vector (N(1)xN(2) image). minperl is an 
%integer specifying the amount of noise, smaller values result in smoother 
%images. The default value is N/2.

if nargin<2
    minperl=min(N)/2;
end

im=zeros(N);
w=min(N);
k=0;
while w>minperl
    k=k+1;
    d=interp2(randn(N),k-1,'makima');
    im=im+k*d(1:N(1),1:N(2));
    w=w-ceil(w/2-1);
end

im=normalizeIm(im);